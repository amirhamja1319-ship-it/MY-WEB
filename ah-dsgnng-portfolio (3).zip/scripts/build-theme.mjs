import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { build } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import sharp from 'sharp';
import * as archiver from 'archiver';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const THEME_FOLDER_NAME = 'ah-dsgnng-portfolio';
const THEME_DIR = path.join(ROOT_DIR, THEME_FOLDER_NAME);
const THEME_ASSETS_DIR = path.join(THEME_DIR, 'assets');
const THEME_CSS_DIR = path.join(THEME_ASSETS_DIR, 'css');
const THEME_JS_DIR = path.join(THEME_ASSETS_DIR, 'js');
const THEME_IMG_DIR = path.join(THEME_ASSETS_DIR, 'images');

const ZIP_NAME = 'ah-dsgnng-wordpress-theme.zip';
const ZIP_OUTPUT_ROOT = path.join(ROOT_DIR, ZIP_NAME);
const ZIP_OUTPUT_PUBLIC = path.join(ROOT_DIR, 'public', ZIP_NAME);

console.log('🚀 Starting AH DSGNNG Portfolio WordPress Theme Builder...');

async function prepareDirectories() {
  console.log('📁 Preparing theme directory structure...');
  if (fs.existsSync(THEME_DIR)) {
    fs.rmSync(THEME_DIR, { recursive: true, force: true });
  }

  fs.mkdirSync(THEME_DIR, { recursive: true });
  fs.mkdirSync(THEME_CSS_DIR, { recursive: true });
  fs.mkdirSync(THEME_JS_DIR, { recursive: true });
  fs.mkdirSync(THEME_IMG_DIR, { recursive: true });
}

async function compileReactApp() {
  console.log('⚡ Compiling React application for WordPress theme with Vite...');
  
  const tempDist = path.join(ROOT_DIR, '.wp-temp-dist');
  if (fs.existsSync(tempDist)) {
    fs.rmSync(tempDist, { recursive: true, force: true });
  }

  await build({
    root: ROOT_DIR,
    base: './',
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': ROOT_DIR,
      },
    },
    build: {
      outDir: tempDist,
      emptyOutDir: true,
      minify: 'esbuild',
      rollupOptions: {
        input: path.join(ROOT_DIR, 'index.html'),
        output: {
          format: 'es',
          entryFileNames: 'assets/js/portfolio.js',
          chunkFileNames: 'assets/js/[name].js',
          assetFileNames: (assetInfo) => {
            if (assetInfo.name && assetInfo.name.endsWith('.css')) {
              return 'assets/css/portfolio.css';
            }
            return 'assets/images/[name][extname]';
          },
        },
      },
    },
  });

  console.log('📦 Transferring compiled production bundles to theme...');
  // Copy JS
  const compiledJs = path.join(tempDist, 'assets', 'js', 'portfolio.js');
  if (fs.existsSync(compiledJs)) {
    fs.copyFileSync(compiledJs, path.join(THEME_JS_DIR, 'portfolio.js'));
  } else {
    // Check if directly in assets/
    const fallbackJs = fs.readdirSync(path.join(tempDist, 'assets')).find(f => f.endsWith('.js'));
    if (fallbackJs) {
      fs.copyFileSync(path.join(tempDist, 'assets', fallbackJs), path.join(THEME_JS_DIR, 'portfolio.js'));
    }
  }

  // Copy CSS
  const compiledCss = path.join(tempDist, 'assets', 'css', 'portfolio.css');
  if (fs.existsSync(compiledCss)) {
    fs.copyFileSync(compiledCss, path.join(THEME_CSS_DIR, 'portfolio.css'));
  } else {
    const fallbackCss = fs.readdirSync(path.join(tempDist, 'assets')).find(f => f.endsWith('.css'));
    if (fallbackCss) {
      fs.copyFileSync(path.join(tempDist, 'assets', fallbackCss), path.join(THEME_CSS_DIR, 'portfolio.css'));
    }
  }

  // Clean temp folder
  fs.rmSync(tempDist, { recursive: true, force: true });
}

async function copyThemeAssets() {
  console.log('🖼️ Copying imagery and assets to theme...');

  // Copy logo from public
  const logoPath = path.join(ROOT_DIR, 'public', 'logo.png');
  if (fs.existsSync(logoPath)) {
    fs.copyFileSync(logoPath, path.join(THEME_IMG_DIR, 'logo.png'));
  }

  // Copy Photoroom image from Images/ and public/
  const photoPath = path.join(ROOT_DIR, 'Images', '1000026141-Photoroom.png');
  if (fs.existsSync(photoPath)) {
    fs.copyFileSync(photoPath, path.join(THEME_IMG_DIR, '1000026141-Photoroom.png'));
    fs.copyFileSync(photoPath, path.join(THEME_IMG_DIR, 'amir-hamza-profile.png'));
  }
  const publicProfile = path.join(ROOT_DIR, 'public', 'amir-hamza-profile.png');
  if (fs.existsSync(publicProfile)) {
    fs.copyFileSync(publicProfile, path.join(THEME_IMG_DIR, 'amir-hamza-profile.png'));
  }

  // Copy public favicons & icons
  const publicDir = path.join(ROOT_DIR, 'public');
  if (fs.existsSync(publicDir)) {
    const files = fs.readdirSync(publicDir);
    for (const file of files) {
      if (file.endsWith('.png') || file.endsWith('.ico') || file.endsWith('.svg')) {
        fs.copyFileSync(path.join(publicDir, file), path.join(THEME_IMG_DIR, file));
      }
    }
  }
}

async function generateThemeScreenshot() {
  console.log('🎨 Generating high-resolution screenshot.png (1200x900)...');

  const width = 1200;
  const height = 900;

  // Read logo if exists for compositing
  const logoPath = path.join(ROOT_DIR, 'public', 'logo.png');
  let logoBuffer = null;
  if (fs.existsSync(logoPath)) {
    logoBuffer = await sharp(logoPath).resize(160, 160).png().toBuffer();
  }

  const svgTemplate = `
  <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#020409"/>
        <stop offset="40%" stop-color="#040c1e"/>
        <stop offset="70%" stop-color="#06122c"/>
        <stop offset="100%" stop-color="#020409"/>
      </linearGradient>

      <linearGradient id="cyanGlow" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#06b6d4"/>
        <stop offset="50%" stop-color="#38bdf8"/>
        <stop offset="100%" stop-color="#3b82f6"/>
      </linearGradient>

      <radialGradient id="radialCyan" cx="70%" cy="30%" r="50%">
        <stop offset="0%" stop-color="#0284c7" stop-opacity="0.35"/>
        <stop offset="100%" stop-color="#020409" stop-opacity="0"/>
      </radialGradient>

      <radialGradient id="radialBlue" cx="20%" cy="80%" r="50%">
        <stop offset="0%" stop-color="#1e3a8a" stop-opacity="0.3"/>
        <stop offset="100%" stop-color="#020409" stop-opacity="0"/>
      </radialGradient>
      
      <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="15" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
    </defs>

    <!-- Background -->
    <rect width="${width}" height="${height}" fill="url(#bgGradient)"/>
    <circle cx="850" cy="280" r="380" fill="url(#radialCyan)"/>
    <circle cx="250" cy="700" r="400" fill="url(#radialBlue)"/>

    <!-- Subtle Grid Overlay -->
    <g opacity="0.06" stroke="#38bdf8" stroke-width="1">
      <path d="M 0,150 L 1200,150 M 0,300 L 1200,300 M 0,450 L 1200,450 M 0,600 L 1200,600 M 0,750 L 1200,750" />
      <path d="M 200,0 L 200,900 M 400,0 L 400,900 M 600,0 L 600,900 M 800,0 L 800,900 M 1000,0 L 1000,900" />
    </g>

    <!-- Outer Frame / Cyber Border -->
    <rect x="40" y="40" width="1120" height="820" rx="32" fill="none" stroke="rgba(56, 189, 248, 0.25)" stroke-width="2"/>
    <rect x="44" y="44" width="1112" height="812" rx="28" fill="rgba(6, 18, 44, 0.4)"/>

    <!-- Brand Header Pill -->
    <g transform="translate(100, 100)">
      <rect width="280" height="42" rx="21" fill="#06183a" stroke="rgba(6, 182, 212, 0.4)" stroke-width="1.5"/>
      <circle cx="22" cy="21" r="5" fill="#22d3ee" filter="url(#glow)"/>
      <text x="38" y="27" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="700" font-size="13" letter-spacing="3" fill="#38bdf8">WORDPRESS THEME</text>
    </g>

    <!-- Main Title -->
    <text x="100" y="260" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="900" font-size="76" fill="#ffffff" letter-spacing="-1.5">
      AH.DSGNNG
    </text>

    <!-- Gradient Sub-Heading -->
    <text x="100" y="340" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="800" font-size="38" fill="url(#cyanGlow)" letter-spacing="-0.5">
      Amir Hamja — Portfolio
    </text>

    <!-- Role Description -->
    <text x="100" y="400" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="500" font-size="24" fill="#94a3b8">
      Graphic Designer &amp; Restaurant Branding Specialist
    </text>

    <!-- Badges Row -->
    <g transform="translate(100, 460)">
      <!-- Badge 1 -->
      <rect x="0" y="0" width="220" height="48" rx="24" fill="#061e38" stroke="rgba(56, 189, 248, 0.3)" stroke-width="1.5"/>
      <text x="110" y="30" text-anchor="middle" font-family="system-ui, sans-serif" font-weight="700" font-size="15" fill="#7dd3fc">Interactive 3D UI</text>

      <!-- Badge 2 -->
      <rect x="235" y="0" width="230" height="48" rx="24" fill="#061e38" stroke="rgba(56, 189, 248, 0.3)" stroke-width="1.5"/>
      <text x="350" y="30" text-anchor="middle" font-family="system-ui, sans-serif" font-weight="700" font-size="15" fill="#7dd3fc">Ultra-Smooth Motion</text>

      <!-- Badge 3 -->
      <rect x="480" y="0" width="220" height="48" rx="24" fill="#061e38" stroke="rgba(56, 189, 248, 0.3)" stroke-width="1.5"/>
      <text x="590" y="30" text-anchor="middle" font-family="system-ui, sans-serif" font-weight="700" font-size="15" fill="#7dd3fc">Fast 24-48h Delivery</text>
    </g>

    <!-- Features Cards Mini Preview Grid -->
    <g transform="translate(100, 560)">
      <!-- Card 1 -->
      <rect x="0" y="0" width="310" height="180" rx="20" fill="rgba(8, 24, 58, 0.75)" stroke="rgba(56, 189, 248, 0.2)" stroke-width="1.5"/>
      <circle cx="45" cy="45" r="18" fill="#082b52"/>
      <text x="45" y="51" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#38bdf8">🎨</text>
      <text x="32" y="100" font-family="sans-serif" font-weight="700" font-size="18" fill="#ffffff">Graphic Designing</text>
      <text x="32" y="130" font-family="sans-serif" font-size="13" fill="#94a3b8">Posters, Menus &amp; Branding</text>

      <!-- Card 2 -->
      <rect x="330" y="0" width="310" height="180" rx="20" fill="rgba(8, 24, 58, 0.75)" stroke="rgba(56, 189, 248, 0.2)" stroke-width="1.5"/>
      <circle cx="375" cy="45" r="18" fill="#082b52"/>
      <text x="375" y="51" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#38bdf8">📱</text>
      <text x="362" y="100" font-family="sans-serif" font-weight="700" font-size="18" fill="#ffffff">Digital QR Menus</text>
      <text x="362" y="130" font-family="sans-serif" font-size="13" fill="#94a3b8">Modern contactless dining</text>

      <!-- Card 3 -->
      <rect x="660" y="0" width="310" height="180" rx="20" fill="rgba(8, 24, 58, 0.75)" stroke="rgba(56, 189, 248, 0.2)" stroke-width="1.5"/>
      <circle cx="705" cy="45" r="18" fill="#082b52"/>
      <text x="705" y="51" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#38bdf8">⚡</text>
      <text x="692" y="100" font-family="sans-serif" font-weight="700" font-size="18" fill="#ffffff">Full Responsive</text>
      <text x="692" y="130" font-family="sans-serif" font-size="13" fill="#94a3b8">Mobile, tablet &amp; desktop</text>
    </g>

    <!-- Footer meta -->
    <text x="100" y="805" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-size="14" fill="#64748b">
      WordPress Classic Theme v1.0.0 • React + Vite Production Architecture • Tested with WP 6.0+
    </text>
  </svg>
  `;

  const composites = [];
  if (logoBuffer) {
    composites.push({
      input: logoBuffer,
      top: 150,
      left: 920,
    });
  }

  const baseSvgBuffer = Buffer.from(svgTemplate);
  const screenshotPath = path.join(THEME_DIR, 'screenshot.png');

  if (composites.length > 0) {
    await sharp(baseSvgBuffer)
      .composite(composites)
      .png()
      .toFile(screenshotPath);
  } else {
    await sharp(baseSvgBuffer)
      .png()
      .toFile(screenshotPath);
  }

  console.log('✅ Screenshot generated at:', screenshotPath);
}

function generatePhpFiles() {
  console.log('📝 Writing WordPress theme template files and style.css...');

  // 1. style.css
  const styleCss = `/*
Theme Name: AH DSGNNG Portfolio
Theme URI: https://ah-dsgnng.vercel.app/
Author: Amir Hamja
Author URI: https://ah-dsgnng.vercel.app/
Description: A premium, futuristic 3D portfolio theme for Amir Hamja (AH.DSGNNG) — Graphic Designer & Restaurant Branding Specialist. Built with high-performance React, Tailwind CSS, smooth Framer Motion animations, interactive 3D service cards, and seamless mobile responsiveness.
Version: 1.0.0
Tested up to: 6.7
Requires at least: 6.0
Requires PHP: 7.4
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: ah-dsgnng-portfolio
Tags: portfolio, one-column, dark-theme, responsive-layout, block-patterns, custom-colors, full-width-template
*/

/* Reset and ensure zero gap above fixed navbar for WordPress admin bar */
body.admin-bar header.fixed {
  top: 32px;
}

@media screen and (max-width: 782px) {
  body.admin-bar header.fixed {
    top: 46px;
  }
}
`;
  fs.writeFileSync(path.join(THEME_DIR, 'style.css'), styleCss, 'utf8');

  // 2. functions.php
  const functionsPhp = `<?php
/**
 * AH DSGNNG Portfolio Theme Functions
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'AH_DSGNNG_VERSION', '1.0.0' );
define( 'AH_DSGNNG_THEME_DIR', get_template_directory() );
define( 'AH_DSGNNG_THEME_URI', get_template_directory_uri() );

/**
 * Theme Setup
 */
function ah_dsgnng_theme_setup() {
    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );

    // Enable post thumbnails
    add_theme_support( 'post-thumbnails' );

    // Add support for custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 120,
        'width'       => 120,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // HTML5 markup support
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Responsive embeds
    add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'ah_dsgnng_theme_setup' );

/**
 * Enqueue Styles and Scripts
 */
function ah_dsgnng_enqueue_scripts() {
    // Google Fonts
    wp_enqueue_style(
        'ah-dsgnng-fonts',
        'https://fonts.googleapis.com/css2?family=Caveat:wght@500;600;700&family=Kaushan+Script&family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Satisfy&family=Space+Grotesk:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Theme style.css
    wp_enqueue_style(
        'ah-dsgnng-theme-style',
        get_stylesheet_uri(),
        array(),
        AH_DSGNNG_VERSION
    );

    // Compiled React App CSS
    $css_path = AH_DSGNNG_THEME_DIR . '/assets/css/portfolio.css';
    $css_version = file_exists( $css_path ) ? filemtime( $css_path ) : AH_DSGNNG_VERSION;
    wp_enqueue_style(
        'ah-dsgnng-portfolio-bundle',
        AH_DSGNNG_THEME_URI . '/assets/css/portfolio.css',
        array( 'ah-dsgnng-fonts' ),
        $css_version
    );

    // Compiled React App JavaScript (ES Module)
    $js_path = AH_DSGNNG_THEME_DIR . '/assets/js/portfolio.js';
    $js_version = file_exists( $js_path ) ? filemtime( $js_path ) : AH_DSGNNG_VERSION;
    wp_enqueue_script(
        'ah-dsgnng-app',
        AH_DSGNNG_THEME_URI . '/assets/js/portfolio.js',
        array(),
        $js_version,
        true // In footer
    );

    // Pass dynamic configuration and paths to React app
    $theme_data = array(
        'themeUrl'   => AH_DSGNNG_THEME_URI,
        'siteUrl'    => home_url( '/' ),
        'siteName'   => get_bloginfo( 'name' ),
        'adminEmail' => get_bloginfo( 'admin_email' ),
        'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
        'nonce'      => wp_create_nonce( 'ah_dsgnng_contact_nonce' ),
        'isLoggedIn' => is_user_logged_in(),
    );
    wp_localize_script( 'ah-dsgnng-app', 'ahDsgnngThemeData', $theme_data );
}
add_action( 'wp_enqueue_scripts', 'ah_dsgnng_enqueue_scripts' );

/**
 * Filter script tag to add type="module" for Vite ES bundle
 */
function ah_dsgnng_add_module_to_script( $tag, $handle, $src ) {
    if ( 'ah-dsgnng-app' === $handle ) {
        return '<script type="module" crossorigin src="' . esc_url( $src ) . '"></script>' . "\\n";
    }
    return $tag;
}
add_filter( 'script_loader_tag', 'ah_dsgnng_add_module_to_script', 10, 3 );

/**
 * Handle Contact Form AJAX Submission via WordPress
 */
function ah_dsgnng_handle_contact_form() {
    check_ajax_referer( 'ah_dsgnng_contact_nonce', 'nonce' );

    $name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    $email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    $phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : 'Not provided';
    $service = isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : 'General Inquiry';
    $message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

    if ( empty( $name ) || empty( $email ) || ! is_email( $email ) ) {
        wp_send_json_error( array( 'message' => 'Please fill in a valid name and email address.' ), 400 );
    }

    $to      = get_option( 'admin_email' );
    $subject = sprintf( '[Portfolio Inquiry] %s from %s', $service, $name );
    $body    = "You received a new inquiry from your AH DSGNNG Portfolio website:\\n\\n";
    $body   .= "Name: " . $name . "\\n";
    $body   .= "Email: " . $email . "\\n";
    $body   .= "Phone: " . $phone . "\\n";
    $body   .= "Service: " . $service . "\\n\\n";
    $body   .= "Message:\\n" . $message . "\\n\\n";
    $body   .= "---\\nSent via AH DSGNNG Portfolio WordPress Theme";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        'Reply-To: ' . $name . ' <' . $email . '>',
    );

    $sent = wp_mail( $to, $subject, $body, $headers );

    if ( $sent ) {
        wp_send_json_success( array( 'message' => 'Your message has been sent successfully!' ) );
    } else {
        wp_send_json_error( array( 'message' => 'Failed to send email. Please use direct email or WhatsApp.' ), 500 );
    }
}
add_action( 'wp_ajax_ah_dsgnng_contact', 'ah_dsgnng_handle_contact_form' );
add_action( 'wp_ajax_nopriv_ah_dsgnng_contact', 'ah_dsgnng_handle_contact_form' );

/**
 * Filter body class
 */
function ah_dsgnng_body_classes( $classes ) {
    $classes[] = 'ah-dsgnng-theme';
    $classes[] = 'bg-[#080D1B]';
    $classes[] = 'text-[#F5F7FF]';
    return $classes;
}
add_filter( 'body_class', 'ah_dsgnng_body_classes' );
`;
  fs.writeFileSync(path.join(THEME_DIR, 'functions.php'), functionsPhp, 'utf8');

  // 3. header.php
  const headerPhp = `<?php
/**
 * The header template for AH DSGNNG Portfolio
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */
?><!doctype html>
<html <?php language_attributes(); ?> class="scroll-smooth">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php wp_head(); ?>
</head>
<body <?php body_class( 'bg-[#080D1B] text-[#F5F7FF] font-sans antialiased selection:bg-[#398BFF] selection:text-white overflow-x-hidden' ); ?>>
<?php wp_body_open(); ?>
`;
  fs.writeFileSync(path.join(THEME_DIR, 'header.php'), headerPhp, 'utf8');

  // 4. footer.php
  const footerPhp = `<?php
/**
 * The footer template for AH DSGNNG Portfolio
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */
?>
<?php wp_footer(); ?>
</body>
</html>
`;
  fs.writeFileSync(path.join(THEME_DIR, 'footer.php'), footerPhp, 'utf8');

  // 5. front-page.php
  const frontPagePhp = `<?php
/**
 * The front page template for AH DSGNNG Portfolio
 *
 * Renders the dedicated React application container (#root).
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div id="root">
    <!-- Accessible SEO and No-Script Fallback Content -->
    <noscript>
        <div style="background-color: #020409; color: #f8fafc; padding: 60px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; text-align: center; min-height: 100vh;">
            <div style="max-width: 680px; margin: 0 auto; background: #06122c; border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 24px; padding: 40px;">
                <h1 style="font-size: 32px; color: #38bdf8; margin-bottom: 12px;">Amir Hamja — AH.DSGNNG</h1>
                <h2 style="font-size: 18px; color: #94a3b8; font-weight: 400; margin-bottom: 24px;">Graphic Designer &amp; Restaurant Branding Specialist</h2>
                <p style="color: #cbd5e1; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
                    Welcome to my creative design portfolio. I craft modern, high-converting visual designs for food businesses, restaurants, and brands worldwide.
                </p>
                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <a href="mailto:amirhamja1319@gmail.com" style="display: inline-block; background: #0284c7; color: #ffffff; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: bold;">
                        Email Me: amirhamja1319@gmail.com
                    </a>
                    <a href="https://wa.me/917054307887" style="display: inline-block; background: #10b981; color: #ffffff; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: bold;">
                        WhatsApp: +91 7054307887
                    </a>
                </div>
            </div>
        </div>
    </noscript>
</div>

<?php
get_footer();
`;
  fs.writeFileSync(path.join(THEME_DIR, 'front-page.php'), frontPagePhp, 'utf8');

  // 6. index.php
  const indexPhp = `<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div id="root">
    <?php if ( have_posts() ) : ?>
        <main class="container mx-auto px-4 py-20 min-h-[60vh] max-w-4xl text-slate-200">
            <?php
            while ( have_posts() ) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'p-8 rounded-3xl bg-[#06122c]/90 border border-cyan-500/30 backdrop-blur-xl mb-8' ); ?>>
                    <header class="entry-header mb-6">
                        <h1 class="text-3xl font-black text-white"><?php the_title(); ?></h1>
                    </header>
                    <div class="entry-content prose prose-invert max-w-none text-slate-300">
                        <?php the_content(); ?>
                    </div>
                </article>
                <?php
            endwhile;
            ?>
        </main>
    <?php else : ?>
        <div class="container mx-auto px-4 py-20 text-center text-slate-400">
            <p><?php esc_html_e( 'No content found.', 'ah-dsgnng-portfolio' ); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php
get_footer();
`;
  fs.writeFileSync(path.join(THEME_DIR, 'index.php'), indexPhp, 'utf8');

  // 7. page.php
  const pagePhp = `<?php
/**
 * The template for displaying all pages
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div class="min-h-screen bg-[#020409] text-white pt-28 pb-16 px-4 sm:px-6">
    <div class="container mx-auto max-w-4xl">
        <?php
        while ( have_posts() ) :
            the_post();
            ?>
            <article id="page-<?php the_ID(); ?>" <?php post_class( 'p-8 sm:p-12 rounded-3xl bg-[#06122c]/90 border border-cyan-500/25 backdrop-blur-2xl shadow-2xl' ); ?>>
                <header class="mb-8 border-b border-cyan-500/20 pb-6">
                    <h1 class="text-3xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                        <?php the_title(); ?>
                    </h1>
                </header>
                <div class="prose prose-invert prose-cyan max-w-none text-slate-300 leading-relaxed">
                    <?php the_content(); ?>
                </div>
            </article>
            <?php
        endwhile;
        ?>
    </div>
</div>

<?php
get_footer();
`;
  fs.writeFileSync(path.join(THEME_DIR, 'page.php'), pagePhp, 'utf8');

  // 8. 404.php
  const error404Php = `<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div class="min-h-screen bg-[#020409] flex items-center justify-center px-4 py-20">
    <div class="max-w-md w-full text-center p-8 sm:p-12 rounded-3xl bg-[#06122c]/90 border border-cyan-500/30 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.85)]">
        <span class="inline-block px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 mb-6">
            Error 404
        </span>
        <h1 class="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 mb-4">
            404
        </h1>
        <h2 class="text-2xl font-bold text-white mb-3">Page Not Found</h2>
        <p class="text-slate-400 text-sm mb-8 leading-relaxed">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full text-sm font-bold text-black bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:shadow-[0_0_25px_rgba(6,182,212,0.6)] transition-all duration-300">
            Return Home
        </a>
    </div>
</div>

<?php
get_footer();
`;
  fs.writeFileSync(path.join(THEME_DIR, '404.php'), error404Php, 'utf8');

  // 9. README.md
  const readmeMd = `# AH DSGNNG Portfolio — WordPress Classic Theme

A premium, modern, futuristic 3D interactive portfolio WordPress theme for Amir Hamja (AH.DSGNNG) — Graphic Designer & Restaurant Branding Specialist.

## Theme Details
- **Theme Name:** AH DSGNNG Portfolio
- **Version:** 1.0.0
- **Author:** Amir Hamja
- **Text Domain:** ah-dsgnng-portfolio
- **Framework:** React + TypeScript + Vite bundled as native WordPress Classic Theme assets
- **Requires at least:** WordPress 6.0+
- **Requires PHP:** 7.4+

---

## 🚀 How to Install

### Method 1: WordPress Dashboard (Recommended)
1. Log into your WordPress Admin Dashboard (\`https://your-domain.com/wp-admin\`).
2. Navigate to **Appearance** → **Themes**.
3. Click the **Add New Theme** button at the top.
4. Click **Upload Theme**.
5. Click **Choose File** and select \`ah-dsgnng-wordpress-theme.zip\`.
6. Click **Install Now**.
7. Once the installation completes, click **Activate**.

### Method 2: Manual FTP / cPanel
1. Unzip \`ah-dsgnng-wordpress-theme.zip\` on your computer.
2. Upload the extracted folder \`ah-dsgnng-portfolio\` into your server's WordPress theme directory:
   \`wp-content/themes/\`
3. Go to **Appearance** → **Themes** in your WordPress dashboard and activate **AH DSGNNG Portfolio**.

---

## ⚙️ Configuration & Features

1. **Homepage Display:**
   - Go to **Settings** → **Reading**.
   - Make sure **Your homepage displays** is set to **Your latest posts** (or a Static Page with front-page template). The theme's \`front-page.php\` automatically mounts the complete interactive portfolio application!

2. **Contact Form Inquiries:**
   - The theme provides a built-in WordPress AJAX handler (\`ah_dsgnng_contact\`) that safely routes inquiries via \`wp_mail()\` to the WordPress administrator email address configured in **Settings** → **General**.
   - Ensure your WordPress host has SMTP or standard mail sending enabled (e.g. using WP Mail SMTP plugin if using Gmail/SMTP).
   - Direct WhatsApp and telephone buttons link directly to Amir Hamja (+91 7054307887).

3. **Admin Bar Support:**
   - The theme automatically adjusts top offsets when the logged-in WordPress Admin Bar is visible, preventing any overlap with the sticky glassmorphic navigation header.

---

## 🔄 How to Update the Theme in the Future
1. Make your code changes in the source React project.
2. Run \`npm run build:theme\` to re-compile production bundles and generate an updated ZIP.
3. In WordPress Dashboard, go to **Appearance** → **Themes** → **Add New Theme** → **Upload Theme**.
4. Upload the new \`ah-dsgnng-wordpress-theme.zip\` and choose **Replace active with uploaded**.
`;
  fs.writeFileSync(path.join(THEME_DIR, 'README.md'), readmeMd, 'utf8');
}

async function createThemeZip() {
  console.log('📦 Creating installable WordPress theme ZIP archive...');

  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(ZIP_OUTPUT_ROOT);
    const archive = new archiver.ZipArchive({
      zlib: { level: 9 }, // Maximum compression
    });

    output.on('close', () => {
      const bytes = archive.pointer();
      const kb = (bytes / 1024).toFixed(2);
      console.log(`✅ ZIP package created successfully! Size: ${kb} KB (${bytes} bytes)`);

      // Also copy to public/ so it can be downloaded via browser
      fs.copyFileSync(ZIP_OUTPUT_ROOT, ZIP_OUTPUT_PUBLIC);
      console.log('✅ ZIP copied to public directory for direct download:', ZIP_OUTPUT_PUBLIC);

      resolve();
    });

    archive.on('error', (err) => {
      reject(err);
    });

    archive.pipe(output);

    // Append files from THEME_DIR into 'ah-dsgnng-portfolio' directory inside the zip
    archive.directory(THEME_DIR, THEME_FOLDER_NAME);

    archive.finalize();
  });
}

async function main() {
  try {
    await prepareDirectories();
    await compileReactApp();
    await copyThemeAssets();
    await generateThemeScreenshot();
    generatePhpFiles();
    await createThemeZip();
    console.log('\\n🎉 All done! WordPress theme package ready at:');
    console.log(`   - Root: ${ZIP_OUTPUT_ROOT}`);
    console.log(`   - Public URL: /${ZIP_NAME}`);
  } catch (err) {
    console.error('❌ Build failed:', err);
    process.exit(1);
  }
}

main();
