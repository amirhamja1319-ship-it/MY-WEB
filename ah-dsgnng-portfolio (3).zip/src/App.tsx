import { useState, useEffect } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import BackgroundEffect from "./components/BackgroundEffect";
import CustomCursor from "./components/CustomCursor";
import { ArrowUp } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [showBackToTop, setShowBackToTop] = useState(false);

  // Handle scroll detection for active section and Back to Top toggle
  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const scrollY = window.scrollY;
          setShowBackToTop(scrollY > 500);

          // Section tracking for header navigation highlighters
          const sections = ["home", "about", "services", "contact"];
          const scrollPosition = scrollY + 250;

          for (const section of sections) {
            const element = document.getElementById(section);
            if (element) {
              const top = element.offsetTop;
              const height = element.offsetHeight;

              if (scrollPosition >= top && scrollPosition < top + height) {
                setActiveSection(section);
                break;
              }
            }
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <div className="relative min-h-screen bg-[#080D1B] text-[#F5F7FF] font-sans antialiased selection:bg-[#398BFF] selection:text-white overflow-x-hidden">
      {/* Custom Ambient Glassmorphic Background */}
      <BackgroundEffect />

      {/* Glowing custom mouse cursor pointer */}
      <CustomCursor />

      {/* Sticky glassmorphic header */}
      <Header activeSection={activeSection} />

      {/* Core Content sections layout */}
      <main className="relative">
        <Hero />
        <About />
        <Services />
        <Contact />
      </main>

      {/* Redesigned luxurious footer */}
      <Footer />

      {/* Float-to-top glowing circle button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 15 }}
            transition={{ duration: 0.3 }}
            onClick={scrollToTop}
            className="fixed bottom-6 right-6 w-12 h-12 rounded-full bg-gradient-to-tr from-[#398BFF] to-[#2563EB] text-white font-black flex items-center justify-center shadow-[0_0_25px_rgba(57,139,255,0.6)] hover:shadow-[0_0_35px_rgba(57,139,255,0.9)] hover:scale-110 active:scale-95 transition-all duration-300 z-50 cursor-pointer border border-white/20"
            aria-label="Back to top"
          >
            <ArrowUp size={20} strokeWidth={2.5} className="text-white" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
