import { useState, useRef, ReactNode, MouseEvent, KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";

interface TiltCardProps {
  children: ReactNode;
  key?: string | number;
  className?: string;
  glareColor?: string;
  maxTilt?: number;
  scaleOnHover?: number;
  perspective?: number;
  onClick?: () => void;
  tabIndex?: number;
  role?: string;
  ariaLabel?: string;
  onKeyDown?: (e: KeyboardEvent<HTMLDivElement>) => void;
}

export default function TiltCard({
  children,
  className = "",
  glareColor = "rgba(57, 139, 255, 0.18)",
  maxTilt = 7,
  scaleOnHover = 1.015,
  perspective = 1000,
  onClick,
  tabIndex,
  role,
  ariaLabel,
  onKeyDown,
}: TiltCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [glare, setGlare] = useState({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (shouldReduceMotion || !cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const xPct = (mouseX / width) * 100;
    const yPct = (mouseY / height) * 100;

    const tiltX = -((mouseY - height / 2) / (height / 2)) * maxTilt;
    const tiltY = ((mouseX - width / 2) / (width / 2)) * maxTilt;

    setTilt({ x: tiltX, y: tiltY });
    setGlare({ x: xPct, y: yPct, opacity: 0.85 });
  };

  const handleMouseEnter = () => {
    if (shouldReduceMotion) return;
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setTilt({ x: 0, y: 0 });
    setGlare((prev) => ({ ...prev, opacity: 0 }));
  };

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      onKeyDown={onKeyDown}
      tabIndex={tabIndex}
      role={role}
      aria-label={ariaLabel}
      animate={{
        rotateX: isHovered && !shouldReduceMotion ? tilt.x : 0,
        rotateY: isHovered && !shouldReduceMotion ? tilt.y : 0,
        scale: isHovered && !shouldReduceMotion ? scaleOnHover : 1,
      }}
      transition={{
        type: "spring",
        stiffness: 350,
        damping: 26,
        mass: 0.6,
      }}
      style={{
        transformStyle: "preserve-3d",
        perspective: `${perspective}px`,
      }}
      className={`relative will-change-transform ${className}`}
    >
      {/* 3D Depth Inner Layer */}
      <div className="relative z-10 w-full h-full" style={{ transform: "translateZ(0px)" }}>
        {children}
      </div>

      {/* Dynamic 3D Glare Sheen Reflection Layer */}
      {!shouldReduceMotion && (
        <div
          className="absolute inset-0 rounded-[inherit] pointer-events-none transition-opacity duration-300 z-20 overflow-hidden"
          style={{
            opacity: glare.opacity,
            background: `radial-gradient(circle 240px at ${glare.x}% ${glare.y}%, ${glareColor}, transparent 70%)`,
            mixBlendMode: "screen",
          }}
        />
      )}
    </motion.div>
  );
}
