import { useState } from "react";

interface LogoImageProps {
  className?: string;
  imgClassName?: string;
  glowColor?: string;
}

export default function LogoImage({ 
  className = "w-16 h-16", 
  imgClassName = ""
}: LogoImageProps) {
  const [srcIndex, setSrcIndex] = useState(0);
  const themeUrl = typeof window !== "undefined" && (window as any).ahDsgnngThemeData?.themeUrl
    ? (window as any).ahDsgnngThemeData.themeUrl
    : "";
  const sources = [
    "https://lh3.googleusercontent.com/d/1l5kZFd5QCKfMQqCwXPlVbGv8ZRBI8rGi",
    ...(themeUrl ? [`${themeUrl}/assets/images/logo.png`] : []),
    "/logo.png"
  ];

  const handleImgError = () => {
    if (srcIndex < sources.length - 1) {
      setSrcIndex((prev) => prev + 1);
    } else {
      setSrcIndex(sources.length);
    }
  };

  const hasImage = srcIndex < sources.length;

  return (
    <div 
      className={`relative rounded-full bg-[#080D1B] border-2 border-[#398BFF]/40 flex items-center justify-center overflow-hidden transition-all duration-300 group shadow-[0_0_15px_rgba(57,139,255,0.3)] ${className}`}
    >
      {hasImage ? (
        <img 
          src={sources[srcIndex]} 
          alt="Amir Hamja Logo" 
          className={`w-full h-full object-cover select-none relative z-0 transition-transform duration-300 group-hover:scale-105 ${imgClassName}`}
          referrerPolicy="no-referrer"
          onError={handleImgError}
        />
      ) : (
        <span className="font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-br from-[#FFFFFF] via-[#6D8DFF] to-[#398BFF] tracking-wider select-none leading-none relative z-0 text-sm">
          AH
        </span>
      )}
    </div>
  );
}
