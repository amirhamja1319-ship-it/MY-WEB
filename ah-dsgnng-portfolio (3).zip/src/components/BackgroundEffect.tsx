import { useReducedMotion } from "motion/react";

export default function BackgroundEffect() {
  const shouldReduceMotion = useReducedMotion();

  return (
    <div className="fixed inset-0 -z-50 overflow-hidden bg-[#080D1B] pointer-events-none select-none">
      {/* Deep midnight navy gradient foundation */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#080D1B] via-[#0C152B] to-[#060A15]" />

      {/* Volumetric ambient electric-blue light orbs */}
      <div 
        className={`absolute top-[-12%] left-[-10%] w-[65vw] h-[65vw] max-w-[850px] max-h-[850px] rounded-full bg-gradient-to-br from-[#398BFF]/14 via-[#6D8DFF]/8 to-transparent blur-[160px] ${
          shouldReduceMotion ? "" : "animate-[pulse_10s_ease-in-out_infinite]"
        }`} 
      />
      <div 
        className={`absolute bottom-[-15%] right-[-10%] w-[60vw] h-[60vw] max-w-[800px] max-h-[800px] rounded-full bg-gradient-to-tl from-[#398BFF]/12 via-[#2563EB]/10 to-transparent blur-[180px] ${
          shouldReduceMotion ? "" : "animate-[pulse_12s_ease-in-out_infinite_reverse]"
        }`} 
      />
      <div 
        className="absolute top-[35%] right-[15%] w-[40vw] h-[40vw] max-w-[550px] max-h-[550px] rounded-full bg-[#6D8DFF]/8 blur-[170px]" 
      />
      <div 
        className="absolute bottom-[30%] left-[10%] w-[35vw] h-[35vw] max-w-[450px] max-h-[450px] rounded-full bg-[#398BFF]/6 blur-[150px]" 
      />

      {/* Subtle modern precision dot / grid overlay */}
      <div 
        className="absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255, 255, 255, 0.4) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.4) 1px, transparent 1px)
          `,
          backgroundSize: "64px 64px",
        }}
      />

      {/* Subtle micro noise texture for frosted depth */}
      <div className="absolute inset-0 noise-overlay opacity-25 mix-blend-overlay" />
    </div>
  );
}
