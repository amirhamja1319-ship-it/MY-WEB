import { useState, ChangeEvent, FormEvent } from "react";
import { motion } from "motion/react";
import { Phone, Mail, MapPin, Instagram, Facebook } from "lucide-react";
import TiltCard from "./TiltCard";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    service: "Graphic Designing - Modern Food Menu Design",
    message: ""
  });
  const [sentSuccess, setSentSuccess] = useState(false);

  const mapsUrl = "https://www.google.com/maps/search/?api=1&query=Kaliachak,Malda,West+Bengal";

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    const key = id === "cf-msg" ? "message" : id.replace("cf-", "");
    setFormData((prev) => ({
      ...prev,
      [key]: value
    }));
  };

  const handleFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    const { name, service, message } = formData;
    const whatsappMessage = `Hello Amir, my name is ${name.trim() || "Client"}.\n\n📌 *Service Interested In:* ${service}\n\n💬 *Project Details:*\n${message.trim()}`;
    const whatsappUrl = `https://wa.me/917054307887?text=${encodeURIComponent(whatsappMessage)}`;
    
    // Open WhatsApp directly with pre-filled message
    window.open(whatsappUrl, "_blank");
    setSentSuccess(true);
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32 overflow-hidden bg-[#080D1B]">
      {/* Volumetric ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-[#398BFF]/8 blur-[180px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-[#6D8DFF]/8 blur-[160px] rounded-full pointer-events-none -z-10" />

      <div className="container mx-auto px-4 sm:px-6 relative z-10 max-w-7xl">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16 sm:mb-20 space-y-4 font-sans">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/15 bg-white/[0.05] text-[10px] font-bold tracking-[0.25em] text-[#398BFF] uppercase shadow-sm backdrop-blur-xl"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#398BFF] shadow-[0_0_8px_#398BFF]" />
            <span>Get In Touch</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display font-black text-3xl sm:text-5xl md:text-6xl leading-tight text-white tracking-tight"
          >
            Let's{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] via-[#6D8DFF] to-[#38BDF8] drop-shadow-[0_0_25px_rgba(57,139,255,0.4)]">
              Work Together!
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-[#A9B5CC] text-base sm:text-lg font-normal max-w-xl mx-auto leading-relaxed"
          >
            Great design is not just looking good,
            <br className="hidden sm:inline" />
            {" "}It’s about growing your business &amp; attracting loyal customers.
          </motion.p>
        </div>

        {/* Contact info cards grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start font-sans">
          
          {/* Left Details Panel with 3D Tilt */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ type: "spring", stiffness: 240, damping: 24 }}
            className="lg:col-span-5 space-y-6"
          >
            <TiltCard maxTilt={5} scaleOnHover={1.01} className="rounded-3xl">
              <div className="p-7 sm:p-8 rounded-[32px] border border-white/12 space-y-6 shadow-[0_25px_60px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.18)] bg-gradient-to-b from-white/[0.08] via-white/[0.03] to-[#0A1224]/85 backdrop-blur-2xl group/card relative overflow-hidden">
                {/* Top Subtle Glare */}
                <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />
                
                {/* Phone Item */}
                <motion.div 
                  whileHover={{ x: 4 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  className="flex items-center gap-4 py-3 border-b border-white/10 cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-[#398BFF]/15 border border-[#398BFF]/40 flex items-center justify-center text-[#398BFF] shrink-0 shadow-sm group-hover:scale-105 group-hover:bg-[#398BFF] group-hover:text-white transition-all duration-300">
                    <Phone size={18} />
                  </div>
                  <div>
                    <span className="block font-bold text-sm text-white">Direct Phone</span>
                    <a href="tel:+917054307887" className="block text-xs sm:text-sm text-[#398BFF] hover:text-white mt-0.5 transition-colors font-medium">
                      +91 7054307887
                    </a>
                  </div>
                </motion.div>

                {/* Email Item */}
                <motion.div 
                  whileHover={{ x: 4 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  className="flex items-center gap-4 py-3 cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-[#398BFF]/15 border border-[#398BFF]/40 flex items-center justify-center text-[#398BFF] shrink-0 shadow-sm group-hover:scale-105 group-hover:bg-[#398BFF] group-hover:text-white transition-all duration-300">
                    <Mail size={18} />
                  </div>
                  <div>
                    <span className="block font-bold text-sm text-white">Email Address</span>
                    <a href="mailto:amirhamja1319@gmail.com" className="block text-xs sm:text-sm text-[#398BFF] hover:text-white mt-0.5 transition-colors font-medium">
                      amirhamja1319@gmail.com
                    </a>
                  </div>
                </motion.div>

                {/* Social links row */}
                <div className="flex flex-wrap gap-2.5 pt-4 border-t border-white/10">
                  <motion.a
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 400, damping: 17 }}
                    href="https://wa.me/917054307887"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-[#10b981]/30 bg-[#10b981]/15 text-xs text-[#34d399] hover:text-white hover:bg-[#10b981]/25 transition-all shadow-sm font-semibold"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
                    </svg>
                    WhatsApp
                  </motion.a>

                  <motion.a
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 400, damping: 17 }}
                    href="https://instagram.com/ah.dsgnng"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-pink-500/30 bg-pink-500/10 text-xs text-pink-300 hover:text-white hover:bg-pink-500/20 transition-all shadow-sm font-semibold"
                  >
                    <Instagram size={14} className="text-pink-400" />
                    Instagram
                  </motion.a>

                  <motion.a
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 400, damping: 17 }}
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-blue-500/30 bg-blue-500/10 text-xs text-blue-300 hover:text-white hover:bg-blue-500/20 transition-all shadow-sm font-semibold"
                  >
                    <Facebook size={14} className="text-blue-400" />
                    Facebook
                  </motion.a>

                  <motion.a
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 400, damping: 17 }}
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-white/15 bg-white/[0.05] text-xs text-[#A9B5CC] hover:text-white hover:bg-white/[0.1] transition-all shadow-sm font-semibold"
                  >
                    <MapPin size={14} className="text-[#398BFF]" />
                    Google Maps
                  </motion.a>
                </div>

              </div>
            </TiltCard>
          </motion.div>

          {/* Right Direct WhatsApp Inquiry Form with 3D Tilt */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ type: "spring", stiffness: 240, damping: 24, delay: 0.1 }}
            className="lg:col-span-7"
          >
            <TiltCard maxTilt={4} scaleOnHover={1.01} className="rounded-3xl">
              <form 
                onSubmit={handleFormSubmit} 
                className="p-7 sm:p-8 rounded-[32px] border border-white/12 bg-gradient-to-b from-white/[0.08] via-white/[0.03] to-[#0A1224]/85 backdrop-blur-2xl space-y-5 shadow-[0_25px_60px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.18)] relative overflow-hidden"
              >
                {/* Top Subtle Glare */}
                <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />

                {/* Full Name */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="cf-name" className="text-xs text-[#A9B5CC] font-semibold tracking-wide">
                    Full Name
                  </label>
                  <input
                    id="cf-name"
                    type="text"
                    required
                    placeholder="Enter your name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="bg-white/[0.04] border border-white/12 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#398BFF] focus:ring-2 focus:ring-[#398BFF]/30 transition-all duration-200"
                  />
                </div>

                {/* Service Selection */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="cf-service" className="text-xs text-[#A9B5CC] font-semibold tracking-wide">
                    Service You Need
                  </label>
                  <select
                    id="cf-service"
                    value={formData.service}
                    onChange={handleInputChange}
                    className="bg-[#0C152B] border border-white/12 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#398BFF] focus:ring-2 focus:ring-[#398BFF]/30 transition-all duration-200 cursor-pointer"
                  >
                    <optgroup label="🎨 Graphic Designing" className="bg-[#080D1B] text-[#398BFF] font-semibold">
                      <option value="Poster Design" className="bg-[#080D1B] text-white">Poster Design</option>
                      <option value="Banner Design" className="bg-[#080D1B] text-white">Banner Design</option>
                      <option value="Modern Food Menu Design" className="bg-[#080D1B] text-white">Modern Food Menu Design</option>
                      <option value="Flyers Design" className="bg-[#080D1B] text-white">Flyers Design</option>
                      <option value="Medical Carousel Design" className="bg-[#080D1B] text-white">Medical Carousel Design</option>
                      <option value="Social Media Post & Ads Design" className="bg-[#080D1B] text-white">Social Media Post &amp; Ads Design</option>
                    </optgroup>
                    <optgroup label="📱 Digital Service for Restaurant" className="bg-[#080D1B] text-[#398BFF] font-semibold">
                      <option value="Digital QR Menu" className="bg-[#080D1B] text-white">Digital QR Menu</option>
                      <option value="Digital Feedback Website" className="bg-[#080D1B] text-white">Digital Feedback Website</option>
                    </optgroup>
                    <optgroup label="🚀 Freelancing Service" className="bg-[#080D1B] text-[#398BFF] font-semibold">
                      <option value="Social Media Management (Instagram & Facebook Modern Posts)" className="bg-[#080D1B] text-white">Social Media Management (Instagram &amp; Facebook Modern Posts)</option>
                    </optgroup>
                    <optgroup label="✨ Complete Solutions" className="bg-[#080D1B] text-[#398BFF] font-semibold">
                      <option value="Complete Branding & Digital Package" className="bg-[#080D1B] text-white">Complete Branding &amp; Digital Package</option>
                      <option value="Custom Requirement" className="bg-[#080D1B] text-white">Custom Requirement</option>
                    </optgroup>
                  </select>
                </div>

                {/* Message */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="cf-msg" className="text-xs text-[#A9B5CC] font-semibold tracking-wide">
                    Message
                  </label>
                  <textarea
                    id="cf-msg"
                    name="message"
                    required
                    placeholder="Describe your design requirement, quantity, or questions..."
                    value={formData.message}
                    onChange={handleInputChange}
                    className="bg-white/[0.04] border border-white/12 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 min-h-[130px] focus:outline-none focus:border-[#398BFF] focus:ring-2 focus:ring-[#398BFF]/30 transition-all duration-200 caret-[#398BFF]"
                  />
                </div>

                {/* Submit button - WhatsApp Auto-Fill Trigger */}
                <motion.button
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: "spring", stiffness: 450, damping: 25 }}
                  type="submit"
                  className="w-full flex items-center justify-center gap-2.5 px-8 py-4 rounded-full text-sm font-bold text-white bg-gradient-to-r from-[#10b981] via-[#059669] to-[#047857] shadow-[0_10px_30px_rgba(16,185,129,0.35)] hover:shadow-[0_15px_40px_rgba(16,185,129,0.5)] transition-all duration-300 cursor-pointer border border-[#34d399]/40 select-none group/btn"
                >
                  <svg className="w-5 h-5 fill-current text-white transition-transform duration-200 group-hover/btn:scale-110" viewBox="0 0 24 24">
                    <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
                  </svg>
                  <span>{sentSuccess ? "Opening WhatsApp Chat..." : "Send Inquiry on WhatsApp"}</span>
                </motion.button>

                <p className="text-[11px] text-[#A9B5CC] leading-normal text-center mt-2 flex items-center justify-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Clicking will instantly open WhatsApp with your name, selected service &amp; message pre-filled.</span>
                </p>
              </form>
            </TiltCard>
          </motion.div>

        </div>

        {/* Lower Map Panel */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ type: "spring", stiffness: 240, damping: 24, delay: 0.15 }}
          className="p-7 sm:p-8 rounded-[32px] border border-white/12 text-center mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 overflow-hidden bg-gradient-to-r from-white/[0.08] via-white/[0.04] to-white/[0.08] backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] font-sans"
        >
          <div className="flex items-center gap-4 text-left">
            <div className="w-12 h-12 rounded-2xl bg-[#398BFF]/15 border border-[#398BFF]/40 flex items-center justify-center text-[#398BFF] shrink-0 shadow-sm">
              <MapPin size={20} />
            </div>
            <div>
              <span className="block font-bold text-sm sm:text-base text-white">Kaliachak, Malda, West Bengal — 732201</span>
              <span className="block text-xs text-[#A9B5CC] mt-0.5">Let's meet up or collaborate remotely worldwide!</span>
            </div>
          </div>
          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 20 }}
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-7 py-3 rounded-full text-xs font-bold tracking-wide border border-white/20 hover:border-[#398BFF] bg-white/[0.06] hover:bg-[#398BFF]/20 text-white transition-all whitespace-nowrap shadow-sm"
          >
            Open in Google Maps
          </motion.a>
        </motion.div>

      </div>
    </section>
  );
}
