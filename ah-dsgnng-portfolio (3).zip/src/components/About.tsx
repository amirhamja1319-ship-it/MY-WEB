import { motion } from "motion/react";
import { MessageCircle, ArrowUpRight } from "lucide-react";
import TiltCard from "./TiltCard";

export default function About() {
  return (
    <section id="about" className="relative py-24 sm:py-32 overflow-hidden bg-[#080D1B]">
      {/* Volumetric ambient background lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-[#398BFF]/8 blur-[180px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-[#6D8DFF]/8 blur-[160px] rounded-full pointer-events-none -z-10" />

      <div className="container mx-auto px-4 sm:px-6 relative z-10 max-w-7xl">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-14 sm:mb-16 space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/15 bg-white/[0.05] text-[10px] font-bold tracking-[0.25em] text-[#398BFF] uppercase shadow-sm backdrop-blur-xl"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#398BFF] shadow-[0_0_8px_#398BFF]" />
            <span>Meet The Designer</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display font-black text-3xl sm:text-5xl md:text-6xl leading-[1.1] text-white tracking-tight"
          >
            About{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] via-[#6D8DFF] to-[#38BDF8] drop-shadow-[0_0_25px_rgba(57,139,255,0.4)]">
              Designer
            </span>
          </motion.h2>
        </div>

        {/* Central About Card with 3D Tilt & Glassmorphism */}
        <div className="max-w-3xl mx-auto">
          <TiltCard maxTilt={4} scaleOnHover={1.01} className="rounded-3xl">
            <div className="p-8 sm:p-12 rounded-[32px] border border-white/12 bg-gradient-to-b from-white/[0.08] via-white/[0.03] to-[#0A1224]/85 backdrop-blur-2xl shadow-[0_25px_60px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.18)] space-y-8 relative overflow-hidden text-center sm:text-left">
              {/* Subtle Top Glare */}
              <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />

              {/* Main Introduction Paragraph */}
              <div className="space-y-4">
                <p className="text-white text-xl sm:text-2xl font-bold leading-relaxed font-sans">
                  Hello, I'm Amir Hamza <span className="text-[#398BFF]">&bull; AH.DSGNNG</span>
                </p>
                <p className="text-[#A9B5CC] text-base sm:text-lg leading-relaxed font-normal font-sans">
                  Your dedicated Creative Graphic Designer &amp; Freelancer based in Kaliachak, Malda. I craft modern, eye-catching, and high-converting visual designs for your business to help you attract more customers &amp; grow.
                </p>
                <p className="font-['Kaushan_Script','Caveat',cursive] text-2xl sm:text-3xl text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] via-[#6D8DFF] to-[#38BDF8] pt-2 drop-shadow-[0_0_20px_rgba(57,139,255,0.4)]">
                  Let’s create something amazing Together!
                </p>
              </div>

              {/* Action Buttons Row */}
              <div className="flex flex-col sm:flex-row items-center gap-4 pt-4 border-t border-white/10 justify-center sm:justify-start">
                <a
                  href="https://wa.me/917054307887?text=Hello%20Amir%2C%20I%20would%20like%20to%20discuss%20a%20project!"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full text-xs sm:text-sm font-bold bg-gradient-to-r from-[#10b981] to-[#059669] text-white shadow-[0_8px_20px_rgba(16,185,129,0.3)] hover:shadow-[0_12px_28px_rgba(16,185,129,0.45)] transition-all cursor-pointer border border-[#34d399]/40"
                >
                  <MessageCircle size={16} />
                  <span>Connect on WhatsApp</span>
                </a>

                <a
                  href="#services"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-xs sm:text-sm font-semibold bg-white/[0.06] hover:bg-white/[0.12] text-white border border-white/15 transition-all"
                >
                  <span>Explore Services</span>
                  <ArrowUpRight size={14} className="text-[#398BFF]" />
                </a>
              </div>

            </div>
          </TiltCard>
        </div>

      </div>
    </section>
  );
}
