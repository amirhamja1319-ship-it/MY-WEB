import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import LogoImage from "./LogoImage";
import { ArrowUpRight, Menu, X, Sparkles } from "lucide-react";

interface HeaderProps {
  activeSection: string;
}

export default function Header({ activeSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 25);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Lock body and HTML scroll when mobile menu is open
  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = "hidden";
      document.documentElement.style.overflow = "hidden";
      document.body.style.touchAction = "none";
    } else {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
      document.body.style.touchAction = "";
    }
    return () => {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
      document.body.style.touchAction = "";
    };
  }, [isMobileOpen]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isMobileOpen) {
        setIsMobileOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isMobileOpen]);

  const menuItems = [
    { id: "home", label: "Home" },
    { id: "about", label: "About" },
    { id: "services", label: "Services" },
    { id: "contact", label: "Contact" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-[#080D1B]/80 backdrop-blur-2xl border-b border-white/10 py-3 shadow-[0_15px_40px_rgba(0,0,0,0.6)]"
            : "py-5 bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 sm:px-6 flex items-center justify-between max-w-7xl">
          {/* Logo / Brand */}
          <a href="#home" className="flex items-center gap-3 group">
            <div className="relative">
              <LogoImage className="w-11 h-11 ring-1 ring-white/20 group-hover:scale-105 transition-transform duration-300 shadow-[0_0_20px_rgba(57,139,255,0.3)]" />
              <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-[#398BFF] rounded-full border-2 border-[#080D1B] animate-pulse" />
            </div>
            <div className="flex flex-col text-left">
              <span className="font-display font-black text-sm sm:text-base tracking-wide text-white">
                AH <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] to-[#6D8DFF]">DSGNNG</span>
              </span>
              <span className="text-[10px] text-[#A9B5CC] uppercase tracking-[0.16em] font-medium font-sans">
                Designer &amp; Freelancer
              </span>
            </div>
          </a>

          {/* Desktop Nav Items with Frosted Glass Container */}
          <nav className="hidden md:flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/[0.05] border border-white/10 backdrop-blur-2xl font-sans shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
            {menuItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  className={`relative px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-200 ${
                    isActive
                      ? "text-white font-bold"
                      : "text-[#A9B5CC] hover:text-white"
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="activeNavIndicator"
                      className="absolute inset-0 rounded-full bg-gradient-to-r from-[#398BFF] to-[#6D8DFF] shadow-[0_0_20px_rgba(57,139,255,0.5)]"
                      transition={{ type: "spring", stiffness: 450, damping: 32 }}
                    />
                  )}
                  <span className="relative z-10">{item.label}</span>
                </a>
              );
            })}
          </nav>

          {/* Actions & Buttons */}
          <div className="flex items-center gap-3">
            {/* Direct WhatsApp CTA Button */}
            <motion.a
              whileHover={{ scale: 1.04, y: -1 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: "spring", stiffness: 400, damping: 20 }}
              href="https://wa.me/917054307887"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-full text-xs font-bold tracking-wider text-white bg-gradient-to-r from-[#398BFF] to-[#2563EB] shadow-[0_0_20px_rgba(57,139,255,0.4)] hover:shadow-[0_0_30px_rgba(57,139,255,0.7)] transition-all duration-300 font-sans cursor-pointer border border-white/20"
            >
              <span>Get in Touch</span>
              <ArrowUpRight size={14} strokeWidth={2.5} />
            </motion.a>

            {/* Mobile Hamburger Button */}
            <button
              type="button"
              onClick={() => setIsMobileOpen((prev) => !prev)}
              className="md:hidden w-11 h-11 rounded-2xl flex items-center justify-center border border-white/15 bg-white/[0.06] hover:bg-white/[0.1] text-white transition-all duration-200 focus:outline-none cursor-pointer shadow-lg active:scale-95 z-50 backdrop-blur-xl"
              aria-label="Toggle menu"
              aria-expanded={isMobileOpen}
            >
              {isMobileOpen ? (
                <X size={20} className="text-white" />
              ) : (
                <Menu size={20} className="text-white" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Fullscreen Glassmorphism View */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[100] bg-[#080D1B]/90 backdrop-blur-3xl flex flex-col justify-between px-6 py-6 font-sans select-none overflow-hidden touch-none h-[100dvh] w-[100vw]"
            style={{ touchAction: "none" }}
          >
            {/* Top Bar: Logo & Close */}
            <div className="flex items-center justify-between w-full max-w-md mx-auto">
              <a
                href="#home"
                onClick={() => setIsMobileOpen(false)}
                className="flex items-center gap-3"
              >
                <LogoImage className="w-11 h-11 ring-1 ring-white/20 shadow-[0_0_15px_rgba(57,139,255,0.3)]" />
                <div className="flex flex-col text-left">
                  <div className="text-base font-black tracking-wide">
                    <span className="text-white">AH. </span>
                    <span className="text-[#398BFF]">DSGNNG</span>
                  </div>
                  <span className="text-[10px] text-[#A9B5CC] uppercase tracking-wider font-semibold">
                    Amir Hamza
                  </span>
                </div>
              </a>

              <button
                type="button"
                onClick={() => setIsMobileOpen(false)}
                className="w-11 h-11 rounded-full bg-white/[0.08] border border-white/15 flex items-center justify-center text-white transition-all duration-200 cursor-pointer shadow-lg active:scale-90"
                aria-label="Close menu"
              >
                <X size={20} />
              </button>
            </div>

            {/* Centered Main Menu Card with Glassmorphic Floating Depth */}
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="w-full max-w-sm mx-auto my-auto rounded-[32px] bg-gradient-to-b from-white/[0.09] to-white/[0.03] border border-white/15 p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.7),inset_0_1px_0_rgba(255,255,255,0.2)] flex flex-col backdrop-blur-2xl"
            >
              <div className="flex flex-col space-y-1">
                {menuItems.map((item, idx) => (
                  <div key={item.id}>
                    <a
                      href={`#${item.id}`}
                      onClick={() => setIsMobileOpen(false)}
                      className={`block w-full py-3 text-center text-lg font-bold tracking-wide transition-colors ${
                        activeSection === item.id
                          ? "text-[#398BFF] font-extrabold"
                          : "text-[#F5F7FF] hover:text-[#398BFF]"
                      }`}
                    >
                      {item.label}
                    </a>
                    {idx < menuItems.length - 1 && (
                      <div className="w-full h-[1px] bg-white/[0.08]" />
                    )}
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Bottom Indicator */}
            <div className="w-full max-w-sm mx-auto text-center pb-2">
              <div className="w-28 h-1 bg-white/20 rounded-full mx-auto" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
