import { motion } from "motion/react";
import { 
  ImageIcon, 
  Layers, 
  UtensilsCrossed, 
  FileText, 
  HeartPulse, 
  Megaphone, 
  QrCode, 
  MessageSquareHeart, 
  Share2, 
  ArrowUpRight,
  Palette,
  Smartphone,
  Briefcase
} from "lucide-react";
import TiltCard from "./TiltCard";

export interface ServiceDetailData {
  id: string;
  num: string;
  categoryKey: "graphic" | "digital" | "freelance";
  categoryLabel: string;
  title: string;
  subtitle: string;
  desc: string;
  icon: any;
  tags: string[];
  features: string[];
  benefits: string[];
}

interface ServiceCategoryGroup {
  key: "graphic" | "digital" | "freelance";
  title: string;
  subtitle: string;
  badge: string;
  icon: any;
  items: ServiceDetailData[];
}

export default function Services() {
  const categoryGroups: ServiceCategoryGroup[] = [
    {
      key: "graphic",
      badge: "Category 01",
      title: "Graphic Designing Services",
      subtitle: "Custom visual designs, marketing creatives, and high-impact branding materials.",
      icon: Palette,
      items: [
        {
          id: "poster-design",
          num: "01",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Poster Design",
          subtitle: "High-impact promotional, event & launch posters",
          desc: "Bold, high-impact poster creatives designed for promotional campaigns, launch events, special offers, and brand announcements with crisp typography and striking visual balance.",
          icon: ImageIcon,
          tags: ["Print & Digital", "Event Posters", "High Resolution"],
          features: [
            "Custom 3D / vector typography & visual concept",
            "High-contrast color psychology to stop viewers in 2 seconds",
            "CMYK 300 DPI print-ready PDF + RGB social story formats",
            "Fast 24-48h turnaround with 100% vector scaling"
          ],
          benefits: [
            "Boost event ticket sales and walk-in attendance",
            "Strengthen brand recall with modern aesthetic visuals",
            "Consistent look across physical walls & social feeds"
          ]
        },
        {
          id: "banner-design",
          num: "02",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Banner Design",
          subtitle: "Outdoor flex, shop front hoardings & web banners",
          desc: "Large-format outdoor flex banners, rollup standees, storefront boards, and digital advertising display banners engineered for maximum visibility from afar.",
          icon: Layers,
          tags: ["Outdoor Flex", "Shop Banners", "Standees"],
          features: [
            "100% vector scalability with zero blur at huge dimensions",
            "Weather-durable contrast considerations for daylight & night",
            "Clear call-to-actions, phone numbers, and QR placements",
            "Direct print-shop coordination guidelines included"
          ],
          benefits: [
            "Attract passing foot traffic to your physical store or cafe",
            "Professional storefront appearance that inspires trust",
            "High durability visual asset for long-term marketing"
          ]
        },
        {
          id: "modern-food-menu",
          num: "03",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Modern Food Menu Design",
          subtitle: "High-converting psychological restaurant menu engineering",
          desc: "Aesthetically pleasing, appetizing food & beverage menus crafted with modern typography, logical category flows, high-margin item highlighting, and mouthwatering layout architecture.",
          icon: UtensilsCrossed,
          tags: ["Restaurant Menus", "Cafe Menus", "Menu Engineering"],
          features: [
            "Psychological menu engineering to highlight signature dishes",
            "Clean categorical divisions (Starters, Mains, Desserts, Shakes)",
            "Dietary icons (Veg, Non-Veg, Chef Specials, Spicy levels)",
            "Fold formats: Single page, Bi-fold, Tri-fold, or Booklet"
          ],
          benefits: [
            "Increase average table order value by 15-25%",
            "Speed up guest ordering decisions during peak rush hours",
            "Elevate dining ambiance and establish premium restaurant branding"
          ]
        },
        {
          id: "flyers-design",
          num: "04",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Flyers Design",
          subtitle: "Direct marketing handouts, newspaper inserts & coupons",
          desc: "Crisp, concise promotional flyers for home delivery menus, neighborhood promotions, festive sales, and new outlet grand opening handouts.",
          icon: FileText,
          tags: ["Handouts", "Delivery Menus", "Discount Flyers"],
          features: [
            "Double-sided or single-sided compact A5 / DL layouts",
            "Coupon discount tear-off tabs and special deal highlights",
            "Direct WhatsApp / Call QR code for immediate ordering",
            "Optimized for mass offset printing with rich ink profiles"
          ],
          benefits: [
            "Drive immediate phone & takeaway orders in local radius",
            "Cost-effective local neighborhood marketing with fast ROI",
            "Clear incentive for new customers to try your products"
          ]
        },
        {
          id: "medical-carousel",
          num: "05",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Medical Carousel Design",
          subtitle: "Doctor OPD schedules, dental clinics & health awareness",
          desc: "Trustworthy, informative, and authoritative medical carousels and health infographics designed for clinics, dental centers, hospitals, and healthcare professionals.",
          icon: HeartPulse,
          tags: ["Clinics", "Dental", "Healthcare Awareness"],
          features: [
            "Clear doctor credential & OPD timing presentation",
            "Symptom-prevention educational multi-slide carousels",
            "Calming clinical color harmonies (Cyan, Teal, Medical White)",
            "Compliant with ethical medical advertising standards"
          ],
          benefits: [
            "Build patient credibility, trust, and doctor authority",
            "Increase clinic appointments & routine checkup bookings",
            "High shareability on Instagram & WhatsApp patient communities"
          ]
        },
        {
          id: "social-media-post-ads",
          num: "06",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Social Media Post & Ads Design",
          subtitle: "Scroll-stopping promotional creatives for Meta & Instagram",
          desc: "Contemporary, brand-aligned social media creatives and paid ad banners tailored for daily posts, weekend promotions, festival greetings, and flash sales.",
          icon: Megaphone,
          tags: ["Instagram Posts", "Facebook Ads", "Viral Creatives"],
          features: [
            "1:1 Square & 4:5 Portrait feed-optimized resolutions",
            "Visual hooks designed to capture attention in 0.8 seconds",
            "Strict compliance with Meta 20% text overlay guidelines",
            "Source templates and easy-to-reschedule format files"
          ],
          benefits: [
            "Lower your cost-per-click (CPC) on Instagram & Meta ads",
            "Maintain an active, professional, and vibrant social feed",
            "Drive higher engagement, likes, saves, and direct inquiries"
          ]
        }
      ]
    },
    {
      key: "digital",
      badge: "Category 02",
      title: "Digital Service for Restaurant",
      subtitle: "Smart contactless dining tech and automated Google review boosters.",
      icon: Smartphone,
      items: [
        {
          id: "digital-qr-menu",
          num: "07",
          categoryKey: "digital",
          categoryLabel: "Digital for Restaurant",
          title: "Digital QR Menu",
          subtitle: "Contactless, fast-loading mobile web menu via table QR scans",
          desc: "Say goodbye to costly printed paper re-prints! A ultra-fast, mobile-friendly digital QR menu website that your guests can scan with their phone camera without installing any app.",
          icon: QrCode,
          tags: ["Contactless Dining", "Zero App Required", "Instant Scan"],
          features: [
            "Instant loading in under 1 second via table acrylic standees",
            "Search, filter by Veg/Non-Veg, and view dish photos",
            "Zero monthly subscription fees — pure lightweight web code",
            "No app installation friction for dining guests"
          ],
          benefits: [
            "Save thousands of rupees in recurring menu reprint costs",
            "Update prices, out-of-stock items, or new dishes instantly",
            "Faster table turnaround and impressed modern diners"
          ]
        },
        {
          id: "digital-feedback-website",
          num: "08",
          categoryKey: "digital",
          categoryLabel: "Digital for Restaurant",
          title: "Digital Feedback Website",
          subtitle: "Smart review routing: 5-Stars to Google, complaints kept private",
          desc: "An intelligent guest feedback portal that automatically encourages 4 & 5-star guests to leave glowing Google reviews, while privately routing lower ratings to management's WhatsApp.",
          icon: MessageSquareHeart,
          tags: ["Reputation Growth", "Google 5-Star", "Private Feedback"],
          features: [
            "Smart Rating Logic: 4-5 stars route directly to your Google Maps review page",
            "1-3 stars open a confidential form sent straight to owner's WhatsApp",
            "Prevents public negative reviews before they damage your reputation",
            "Captures customer phone numbers for festival SMS promotions"
          ],
          benefits: [
            "Skyrocket your Google Maps local SEO ranking & star count",
            "Resolve customer grievances privately before they post online",
            "Attract more walk-ins searching for 'Best Restaurant Near Me'"
          ]
        }
      ]
    },
    {
      key: "freelance",
      badge: "Category 03",
      title: "Freelancing Service",
      subtitle: "Dedicated social media management with weekly & monthly graphic design.",
      icon: Briefcase,
      items: [
        {
          id: "social-media-management",
          num: "09",
          categoryKey: "freelance",
          categoryLabel: "Freelancing Service",
          title: "Social Media Management",
          subtitle: "Instagram & Facebook Modern Posts dedicated management",
          desc: "End-to-end management of your brand's Instagram and Facebook feed with clean, modern graphic posts tailored for Restaurants, Cafes, Dental Clinics, Healthcare Centers, and local businesses.",
          icon: Share2,
          tags: ["Modern Post Designs", "Restaurants & Cafes", "Dental & Clinics"],
          features: [
            "Modern post designs for Instagram (1:1 feed) and Facebook creatives",
            "Targeted for Restaurants, Cafes, Dental, Clinics & Retail brands",
            "Includes content calendar planning, graphic design, and hashtags",
            "Weekly performance updates and rapid turnaround on promotions"
          ],
          benefits: [
            "Free up your time while your brand maintains an active social presence",
            "Convert casual social followers into paying restaurant guests & clinic patients",
            "Consistent, high-end visual aesthetics matching your physical business"
          ]
        }
      ]
    }
  ];

  return (
    <section id="services" className="relative py-24 sm:py-32 overflow-hidden bg-[#080D1B]">
      {/* Ambient background volumetric lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[85vw] h-[55vw] max-w-[1100px] max-h-[700px] bg-[#398BFF]/8 blur-[190px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#6D8DFF]/8 blur-[160px] rounded-full pointer-events-none -z-10" />

      <div className="container mx-auto px-4 sm:px-6 relative z-10 max-w-7xl">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16 sm:mb-20 space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/15 bg-white/[0.05] text-[10px] font-bold tracking-[0.25em] text-[#398BFF] uppercase shadow-sm backdrop-blur-xl"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#398BFF] shadow-[0_0_8px_#398BFF]" />
            <span>Creative Solutions</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display font-black text-3xl sm:text-5xl md:text-6xl leading-[1.1] text-white tracking-tight"
          >
            Our Creative{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] via-[#6D8DFF] to-[#38BDF8] drop-shadow-[0_0_25px_rgba(57,139,255,0.4)]">
              Services
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-[#A9B5CC] text-base sm:text-lg font-normal max-w-2xl mx-auto leading-relaxed pt-1"
          >
            High-converting visual designs &amp; digital solutions engineered to elevate your brand presence and drive real customer engagement.
          </motion.p>
        </div>

        {/* Divided Category Blocks with Glassmorphism Panels */}
        <div className="space-y-12 sm:space-y-16">
          {categoryGroups.map((group, groupIdx) => {
            const GroupIcon = group.icon;
            return (
              <motion.div 
                key={group.key}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{
                  type: "spring",
                  stiffness: 240,
                  damping: 26,
                  delay: groupIdx * 0.1,
                }}
                className="relative rounded-[32px] border border-white/12 bg-gradient-to-b from-white/[0.08] via-white/[0.03] to-[#0A1224]/85 backdrop-blur-2xl shadow-[0_25px_60px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.18)] p-6 sm:p-8 md:p-10 overflow-hidden group/block"
              >
                {/* Subtle Top Glare */}
                <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />

                {/* Category Header Bar */}
                <div className="flex items-center justify-between gap-4 pb-6 mb-8 border-b border-white/10 relative z-10 flex-wrap">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#398BFF]/15 border border-[#398BFF]/35 flex items-center justify-center text-[#398BFF] shrink-0 shadow-[0_0_20px_rgba(57,139,255,0.25)] transition-transform duration-300 group-hover/block:scale-105">
                      <GroupIcon size={24} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2.5 mb-1">
                        <span className="text-[10px] font-mono uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full border border-[#398BFF]/30 bg-[#398BFF]/10 text-[#398BFF]">
                          {group.badge}
                        </span>
                        <span className="text-xs text-[#A9B5CC] font-mono font-medium">
                          {group.items.length} {group.items.length === 1 ? "Service" : "Services"}
                        </span>
                      </div>
                      <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight">
                        {group.title}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Service Cards Grid for this Category */}
                <div className={`grid grid-cols-1 ${group.items.length > 2 ? 'md:grid-cols-2 lg:grid-cols-3' : group.items.length === 2 ? 'md:grid-cols-2' : 'max-w-xl'} gap-4 sm:gap-5 relative z-10`}>
                  {group.items.map((service) => {
                    const IconComponent = service.icon;
                    const whatsappUrl = `https://wa.me/917054307887?text=${encodeURIComponent(
                      `Hello Amir, I am interested in your ${service.title} (${service.categoryLabel}) service. Please share details and pricing!`
                    )}`;

                    return (
                      <TiltCard
                        key={service.id}
                        maxTilt={6}
                        scaleOnHover={1.02}
                        className="rounded-2xl cursor-pointer"
                      >
                        <a
                          href={whatsappUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="relative p-5 rounded-2xl border border-white/10 hover:border-[#398BFF]/40 bg-white/[0.04] hover:bg-[#398BFF]/[0.05] group transition-all duration-300 overflow-hidden flex items-center justify-between gap-4 shadow-sm hover:shadow-[0_12px_32px_rgba(0,0,0,0.5)] select-none block"
                          aria-label={`Inquire about ${service.title} on WhatsApp`}
                        >
                          <div className="flex items-center gap-3.5 relative z-10">
                            {/* Icon with 3D Pop */}
                            <div className="w-11 h-11 rounded-xl border border-white/15 bg-white/[0.06] flex items-center justify-center shrink-0 shadow-sm text-[#398BFF] group-hover:scale-105 group-hover:bg-[#398BFF] group-hover:text-white group-hover:border-white/30 transition-all duration-300 ease-out">
                              <IconComponent size={20} />
                            </div>

                            {/* Main Title */}
                            <div>
                              <h4 className="font-display font-extrabold text-base sm:text-lg text-white group-hover:text-[#398BFF] transition-colors duration-200 tracking-tight">
                                {service.title}
                              </h4>
                              <p className="text-[11px] text-[#A9B5CC] line-clamp-1 mt-0.5">
                                {service.subtitle}
                              </p>
                            </div>
                          </div>

                          {/* Service Number */}
                          <div className="shrink-0 relative z-10">
                            <span className="font-space text-xs text-[#A9B5CC] font-bold tracking-widest group-hover:text-[#398BFF] transition-colors duration-200">
                              {service.num}
                            </span>
                          </div>
                        </a>
                      </TiltCard>
                    );
                  })}
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
