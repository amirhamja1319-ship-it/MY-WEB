import { motion } from "motion/react";
import { Phone, ArrowUpRight } from "lucide-react";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[92vh] pt-32 pb-20 sm:pt-36 sm:pb-28 md:pt-40 md:pb-32 flex items-center justify-center overflow-hidden">
      {/* Ambient background volumetric lighting */}
      <div className="absolute top-1/4 left-1/4 w-[50vw] h-[50vw] max-w-[700px] max-h-[700px] bg-[#398BFF]/12 blur-[170px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-1/4 w-[45vw] h-[45vw] max-w-[600px] max-h-[600px] bg-[#6D8DFF]/10 blur-[180px] rounded-full pointer-events-none -z-10" />

      <div className="container mx-auto px-4 sm:px-6 relative z-10 max-w-5xl">
        <div className="max-w-3xl mx-auto space-y-8 text-center flex flex-col items-center">
          
          {/* Status Indicator Glass Pill */}
          <motion.div
            initial={{ opacity: 0, y: -15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="inline-flex items-center gap-2.5 px-4.5 py-2 rounded-full bg-white/[0.06] border border-white/15 text-xs font-semibold text-[#F5F7FF] tracking-wide font-sans shadow-[0_4px_20px_rgba(0,0,0,0.3)] backdrop-blur-xl"
          >
            <span className="w-2 h-2 rounded-full bg-[#398BFF] shadow-[0_0_10px_#398BFF] animate-pulse" />
            <span>Available for Freelance Projects</span>
          </motion.div>

          {/* Main Headline */}
          <div className="space-y-3 select-none">
            <h1 className="font-display font-black text-6xl sm:text-7xl md:text-8xl lg:text-9xl tracking-tight leading-[0.92]">
              <span className="block text-[#F5F7FF]">
                AH.
              </span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] via-[#6D8DFF] to-[#38BDF8] drop-shadow-[0_0_35px_rgba(57,139,255,0.4)]">
                DSGNNG
              </span>
            </h1>
            <p className="text-sm sm:text-base font-mono uppercase tracking-[0.2em] text-[#A9B5CC] font-semibold pt-1">
              Creative Designer &amp; Restaurant Branding Specialist
            </p>
          </div>

          {/* Tagline Callout */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="pt-1"
          >
            <p className="font-['Kaushan_Script','Caveat',cursive] text-2xl sm:text-3xl text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] via-[#6D8DFF] to-[#38BDF8] drop-shadow-[0_0_20px_rgba(57,139,255,0.4)]">
              Let’s create something amazing Together!
            </p>
          </motion.div>

          {/* Primary Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-3.5 sm:gap-4 justify-center w-full max-w-md sm:max-w-none pt-2"
          >
            {/* WhatsApp Button */}
            <motion.a
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: "spring", stiffness: 400, damping: 20 }}
              href="https://wa.me/917054307887"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full text-sm font-bold bg-[#10b981]/15 hover:bg-[#10b981]/25 text-[#34d399] border border-[#10b981]/40 shadow-[0_8px_25px_rgba(16,185,129,0.2)] transition-all font-sans cursor-pointer backdrop-blur-xl"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
              </svg>
              <span>WhatsApp Me</span>
            </motion.a>

            {/* Call Phone Button */}
            <motion.a
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: "spring", stiffness: 400, damping: 20 }}
              href="tel:+917054307887"
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-full text-sm font-bold bg-white/[0.06] hover:bg-white/[0.12] text-white border border-white/15 shadow-sm transition-all font-sans cursor-pointer backdrop-blur-xl"
            >
              <Phone size={16} className="text-[#398BFF]" />
              <span>+91 7054307887</span>
            </motion.a>

            {/* Services Anchor Link */}
            <motion.a
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: "spring", stiffness: 400, damping: 20 }}
              href="#services"
              className="inline-flex items-center justify-center gap-1.5 px-5 py-3.5 rounded-full text-sm font-semibold text-[#A9B5CC] hover:text-white transition-colors"
            >
              <span>Explore Services</span>
              <ArrowUpRight size={15} />
            </motion.a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
