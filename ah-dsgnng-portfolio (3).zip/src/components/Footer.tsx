import { motion } from "motion/react";
import LogoImage from "./LogoImage";
import { Instagram, Facebook, ArrowUpRight } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/10 bg-[#060A15] py-16 sm:py-20 overflow-hidden">
      {/* Top ambient glow bar */}
      <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-[#398BFF]/60 to-transparent shadow-[0_0_20px_#398BFF]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-20 bg-[#398BFF]/10 blur-3xl pointer-events-none rounded-full" />

      <div className="container mx-auto px-4 sm:px-6 relative z-10 font-sans max-w-7xl">
        
        {/* Upper Column Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 sm:gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="space-y-5">
            <div className="flex items-center gap-3">
              <LogoImage className="w-12 h-12 ring-1 ring-white/15" />
              <div className="flex flex-col">
                <span className="font-display font-black text-sm tracking-wide text-white">
                  AH <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#398BFF] to-[#6D8DFF]">DSGNNG</span>
                </span>
                <span className="text-[9px] text-[#A9B5CC] uppercase tracking-widest font-semibold mt-0.5">
                  Designer &amp; Freelancer
                </span>
              </div>
            </div>
            <p className="text-[#A9B5CC] text-xs sm:text-sm font-normal leading-relaxed max-w-xs">
              Specializing in Social Media Management &amp; Graphic Design services to attract more customers and boost brand value.
            </p>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-4">
            <h5 className="font-display font-bold text-xs tracking-widest uppercase text-white flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#398BFF] shadow-[0_0_6px_#398BFF]" />
              Quick Links
            </h5>
            <ul className="space-y-2.5">
              <li>
                <a href="#home" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200 font-medium">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200 font-medium">
                  About
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200 font-medium">
                  Services
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200 font-medium">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Services Column */}
          <div className="space-y-4">
            <h5 className="font-display font-bold text-xs tracking-widest uppercase text-white flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#398BFF] shadow-[0_0_6px_#398BFF]" />
              Services
            </h5>
            <ul className="space-y-2.5 font-medium">
              <li>
                <a href="#services" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200">
                  Modern Food Menu Design
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200">
                  Poster &amp; Banner Creatives
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200">
                  Digital QR Menu System
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#A9B5CC] text-xs sm:text-sm hover:text-white transition-colors duration-200">
                  Social Media Post Management
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details Column */}
          <div className="space-y-4">
            <h5 className="font-display font-bold text-xs tracking-widest uppercase text-white flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#398BFF] shadow-[0_0_6px_#398BFF]" />
              Direct Contact
            </h5>
            <ul className="space-y-2.5 text-[#A9B5CC] text-xs sm:text-sm font-normal">
              <li>
                <a href="tel:+917054307887" className="hover:text-white transition-colors duration-200 font-medium">
                  +91 7054307887
                </a>
              </li>
              <li>
                <a href="mailto:amirhamja1319@gmail.com" className="hover:text-white transition-colors duration-200 font-medium">
                  amirhamja1319@gmail.com
                </a>
              </li>
              <li>
                <span className="font-medium">Kaliachak, Malda, WB</span>
              </li>
            </ul>

            {/* Social handles */}
            <div className="flex gap-2.5 pt-2">
              <motion.a
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
                href="https://wa.me/917054307887"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-white/15 hover:border-emerald-400/60 bg-white/[0.05] hover:bg-emerald-500/15 flex items-center justify-center text-[#A9B5CC] hover:text-emerald-300 transition-colors shadow-sm"
                aria-label="WhatsApp Link"
              >
                <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
                </svg>
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
                href="https://instagram.com/ah.dsgnng"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-white/15 hover:border-pink-400/60 bg-white/[0.05] hover:bg-pink-500/15 flex items-center justify-center text-[#A9B5CC] hover:text-pink-300 transition-colors shadow-sm"
                aria-label="Instagram Link"
              >
                <Instagram size={17} />
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-white/15 hover:border-blue-400/60 bg-white/[0.05] hover:bg-blue-500/15 flex items-center justify-center text-[#A9B5CC] hover:text-blue-300 transition-colors shadow-sm"
                aria-label="Facebook Link"
              >
                <Facebook size={17} />
              </motion.a>
            </div>
          </div>

        </div>

        {/* Lower Meta Copyright */}
        <div className="pt-8 border-t border-white/10 text-xs text-[#A9B5CC] text-center font-normal">
          <p>
            &copy; {currentYear} <span className="text-white font-bold tracking-wider">AH.DSGNNG</span> &bull; Amir Hamza &bull; Empowering Brands with Creative Visuals &amp; Digital Solutions.
          </p>
        </div>

      </div>
    </footer>
  );
}
