# AH DSGNNG Portfolio — WordPress Classic Theme

A premium, modern, futuristic 3D interactive portfolio WordPress theme for Amir Hamja (AH.DSGNNG) — Graphic Designer & Restaurant Branding Specialist.

## Theme Details
- **Theme Name:** AH DSGNNG Portfolio
- **Version:** 1.0.0
- **Author:** Amir Hamja
- **Text Domain:** ah-dsgnng-portfolio
- **Framework:** React + TypeScript + Vite bundled as native WordPress Classic Theme assets
- **Requires at least:** WordPress 6.0+
- **Requires PHP:** 7.4+

---

## 🚀 How to Install

### Method 1: WordPress Dashboard (Recommended)
1. Log into your WordPress Admin Dashboard (`https://your-domain.com/wp-admin`).
2. Navigate to **Appearance** → **Themes**.
3. Click the **Add New Theme** button at the top.
4. Click **Upload Theme**.
5. Click **Choose File** and select `ah-dsgnng-wordpress-theme.zip`.
6. Click **Install Now**.
7. Once the installation completes, click **Activate**.

### Method 2: Manual FTP / cPanel
1. Unzip `ah-dsgnng-wordpress-theme.zip` on your computer.
2. Upload the extracted folder `ah-dsgnng-portfolio` into your server's WordPress theme directory:
   `wp-content/themes/`
3. Go to **Appearance** → **Themes** in your WordPress dashboard and activate **AH DSGNNG Portfolio**.

---

## ⚙️ Configuration & Features

1. **Homepage Display:**
   - Go to **Settings** → **Reading**.
   - Make sure **Your homepage displays** is set to **Your latest posts** (or a Static Page with front-page template). The theme's `front-page.php` automatically mounts the complete interactive portfolio application!

2. **Contact Form Inquiries:**
   - The theme provides a built-in WordPress AJAX handler (`ah_dsgnng_contact`) that safely routes inquiries via `wp_mail()` to the WordPress administrator email address configured in **Settings** → **General**.
   - Ensure your WordPress host has SMTP or standard mail sending enabled (e.g. using WP Mail SMTP plugin if using Gmail/SMTP).
   - Direct WhatsApp and telephone buttons link directly to Amir Hamja (+91 7054307887).

3. **Admin Bar Support:**
   - The theme automatically adjusts top offsets when the logged-in WordPress Admin Bar is visible, preventing any overlap with the sticky glassmorphic navigation header.

---

## 🔄 How to Update the Theme in the Future
1. Make your code changes in the source React project.
2. Run `npm run build:theme` to re-compile production bundles and generate an updated ZIP.
3. In WordPress Dashboard, go to **Appearance** → **Themes** → **Add New Theme** → **Upload Theme**.
4. Upload the new `ah-dsgnng-wordpress-theme.zip` and choose **Replace active with uploaded**.
