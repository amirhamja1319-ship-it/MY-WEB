<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div id="root">
    <?php if ( have_posts() ) : ?>
        <main class="container mx-auto px-4 py-20 min-h-[60vh] max-w-4xl text-slate-200">
            <?php
            while ( have_posts() ) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'p-8 rounded-3xl bg-[#06122c]/90 border border-cyan-500/30 backdrop-blur-xl mb-8' ); ?>>
                    <header class="entry-header mb-6">
                        <h1 class="text-3xl font-black text-white"><?php the_title(); ?></h1>
                    </header>
                    <div class="entry-content prose prose-invert max-w-none text-slate-300">
                        <?php the_content(); ?>
                    </div>
                </article>
                <?php
            endwhile;
            ?>
        </main>
    <?php else : ?>
        <div class="container mx-auto px-4 py-20 text-center text-slate-400">
            <p><?php esc_html_e( 'No content found.', 'ah-dsgnng-portfolio' ); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php
get_footer();
