<?php
/**
 * The header template for AH DSGNNG Portfolio
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */
?><!doctype html>
<html <?php language_attributes(); ?> class="scroll-smooth">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php wp_head(); ?>
</head>
<body <?php body_class( 'bg-[#080D1B] text-[#F5F7FF] font-sans antialiased selection:bg-[#398BFF] selection:text-white overflow-x-hidden' ); ?>>
<?php wp_body_open(); ?>
