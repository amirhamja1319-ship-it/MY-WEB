<?php
/**
 * The footer template for AH DSGNNG Portfolio
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */
?>
<?php wp_footer(); ?>
</body>
</html>
