<?php
/**
 * The front page template for AH DSGNNG Portfolio
 *
 * Renders the dedicated React application container (#root).
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div id="root">
    <!-- Accessible SEO and No-Script Fallback Content -->
    <noscript>
        <div style="background-color: #020409; color: #f8fafc; padding: 60px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; text-align: center; min-height: 100vh;">
            <div style="max-width: 680px; margin: 0 auto; background: #06122c; border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 24px; padding: 40px;">
                <h1 style="font-size: 32px; color: #38bdf8; margin-bottom: 12px;">Amir Hamja — AH.DSGNNG</h1>
                <h2 style="font-size: 18px; color: #94a3b8; font-weight: 400; margin-bottom: 24px;">Graphic Designer &amp; Restaurant Branding Specialist</h2>
                <p style="color: #cbd5e1; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
                    Welcome to my creative design portfolio. I craft modern, high-converting visual designs for food businesses, restaurants, and brands worldwide.
                </p>
                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <a href="mailto:amirhamja1319@gmail.com" style="display: inline-block; background: #0284c7; color: #ffffff; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: bold;">
                        Email Me: amirhamja1319@gmail.com
                    </a>
                    <a href="https://wa.me/917054307887" style="display: inline-block; background: #10b981; color: #ffffff; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: bold;">
                        WhatsApp: +91 7054307887
                    </a>
                </div>
            </div>
        </div>
    </noscript>
</div>

<?php
get_footer();
