<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div class="min-h-screen bg-[#020409] flex items-center justify-center px-4 py-20">
    <div class="max-w-md w-full text-center p-8 sm:p-12 rounded-3xl bg-[#06122c]/90 border border-cyan-500/30 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.85)]">
        <span class="inline-block px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 mb-6">
            Error 404
        </span>
        <h1 class="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 mb-4">
            404
        </h1>
        <h2 class="text-2xl font-bold text-white mb-3">Page Not Found</h2>
        <p class="text-slate-400 text-sm mb-8 leading-relaxed">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full text-sm font-bold text-black bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:shadow-[0_0_25px_rgba(6,182,212,0.6)] transition-all duration-300">
            Return Home
        </a>
    </div>
</div>

<?php
get_footer();
