<?php
/**
 * AH DSGNNG Portfolio Theme Functions
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'AH_DSGNNG_VERSION', '1.0.0' );
define( 'AH_DSGNNG_THEME_DIR', get_template_directory() );
define( 'AH_DSGNNG_THEME_URI', get_template_directory_uri() );

/**
 * Theme Setup
 */
function ah_dsgnng_theme_setup() {
    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );

    // Enable post thumbnails
    add_theme_support( 'post-thumbnails' );

    // Add support for custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 120,
        'width'       => 120,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // HTML5 markup support
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Responsive embeds
    add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'ah_dsgnng_theme_setup' );

/**
 * Enqueue Styles and Scripts
 */
function ah_dsgnng_enqueue_scripts() {
    // Google Fonts
    wp_enqueue_style(
        'ah-dsgnng-fonts',
        'https://fonts.googleapis.com/css2?family=Caveat:wght@500;600;700&family=Kaushan+Script&family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Satisfy&family=Space+Grotesk:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Theme style.css
    wp_enqueue_style(
        'ah-dsgnng-theme-style',
        get_stylesheet_uri(),
        array(),
        AH_DSGNNG_VERSION
    );

    // Compiled React App CSS
    $css_path = AH_DSGNNG_THEME_DIR . '/assets/css/portfolio.css';
    $css_version = file_exists( $css_path ) ? filemtime( $css_path ) : AH_DSGNNG_VERSION;
    wp_enqueue_style(
        'ah-dsgnng-portfolio-bundle',
        AH_DSGNNG_THEME_URI . '/assets/css/portfolio.css',
        array( 'ah-dsgnng-fonts' ),
        $css_version
    );

    // Compiled React App JavaScript (ES Module)
    $js_path = AH_DSGNNG_THEME_DIR . '/assets/js/portfolio.js';
    $js_version = file_exists( $js_path ) ? filemtime( $js_path ) : AH_DSGNNG_VERSION;
    wp_enqueue_script(
        'ah-dsgnng-app',
        AH_DSGNNG_THEME_URI . '/assets/js/portfolio.js',
        array(),
        $js_version,
        true // In footer
    );

    // Pass dynamic configuration and paths to React app
    $theme_data = array(
        'themeUrl'   => AH_DSGNNG_THEME_URI,
        'siteUrl'    => home_url( '/' ),
        'siteName'   => get_bloginfo( 'name' ),
        'adminEmail' => get_bloginfo( 'admin_email' ),
        'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
        'nonce'      => wp_create_nonce( 'ah_dsgnng_contact_nonce' ),
        'isLoggedIn' => is_user_logged_in(),
    );
    wp_localize_script( 'ah-dsgnng-app', 'ahDsgnngThemeData', $theme_data );
}
add_action( 'wp_enqueue_scripts', 'ah_dsgnng_enqueue_scripts' );

/**
 * Filter script tag to add type="module" for Vite ES bundle
 */
function ah_dsgnng_add_module_to_script( $tag, $handle, $src ) {
    if ( 'ah-dsgnng-app' === $handle ) {
        return '<script type="module" crossorigin src="' . esc_url( $src ) . '"></script>' . "\n";
    }
    return $tag;
}
add_filter( 'script_loader_tag', 'ah_dsgnng_add_module_to_script', 10, 3 );

/**
 * Handle Contact Form AJAX Submission via WordPress
 */
function ah_dsgnng_handle_contact_form() {
    check_ajax_referer( 'ah_dsgnng_contact_nonce', 'nonce' );

    $name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    $email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    $phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : 'Not provided';
    $service = isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : 'General Inquiry';
    $message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

    if ( empty( $name ) || empty( $email ) || ! is_email( $email ) ) {
        wp_send_json_error( array( 'message' => 'Please fill in a valid name and email address.' ), 400 );
    }

    $to      = get_option( 'admin_email' );
    $subject = sprintf( '[Portfolio Inquiry] %s from %s', $service, $name );
    $body    = "You received a new inquiry from your AH DSGNNG Portfolio website:\n\n";
    $body   .= "Name: " . $name . "\n";
    $body   .= "Email: " . $email . "\n";
    $body   .= "Phone: " . $phone . "\n";
    $body   .= "Service: " . $service . "\n\n";
    $body   .= "Message:\n" . $message . "\n\n";
    $body   .= "---\nSent via AH DSGNNG Portfolio WordPress Theme";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        'Reply-To: ' . $name . ' <' . $email . '>',
    );

    $sent = wp_mail( $to, $subject, $body, $headers );

    if ( $sent ) {
        wp_send_json_success( array( 'message' => 'Your message has been sent successfully!' ) );
    } else {
        wp_send_json_error( array( 'message' => 'Failed to send email. Please use direct email or WhatsApp.' ), 500 );
    }
}
add_action( 'wp_ajax_ah_dsgnng_contact', 'ah_dsgnng_handle_contact_form' );
add_action( 'wp_ajax_nopriv_ah_dsgnng_contact', 'ah_dsgnng_handle_contact_form' );

/**
 * Filter body class
 */
function ah_dsgnng_body_classes( $classes ) {
    $classes[] = 'ah-dsgnng-theme';
    $classes[] = 'bg-[#080D1B]';
    $classes[] = 'text-[#F5F7FF]';
    return $classes;
}
add_filter( 'body_class', 'ah_dsgnng_body_classes' );
