<?php
/**
 * The template for displaying all pages
 *
 * @package AH_DSGNNG_Portfolio
 * @version 1.0.0
 */

get_header();
?>

<div class="min-h-screen bg-[#020409] text-white pt-28 pb-16 px-4 sm:px-6">
    <div class="container mx-auto max-w-4xl">
        <?php
        while ( have_posts() ) :
            the_post();
            ?>
            <article id="page-<?php the_ID(); ?>" <?php post_class( 'p-8 sm:p-12 rounded-3xl bg-[#06122c]/90 border border-cyan-500/25 backdrop-blur-2xl shadow-2xl' ); ?>>
                <header class="mb-8 border-b border-cyan-500/20 pb-6">
                    <h1 class="text-3xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                        <?php the_title(); ?>
                    </h1>
                </header>
                <div class="prose prose-invert prose-cyan max-w-none text-slate-300 leading-relaxed">
                    <?php the_content(); ?>
                </div>
            </article>
            <?php
        endwhile;
        ?>
    </div>
</div>

<?php
get_footer();
